
create procedure [dbo].[Kind_criteria_delete]
	@ID_Kind_criteria [int]
as
	delete from [dbo].[Kind_criteria]
where
	[ID_Kind_criteria] = @ID_Kind_criteria
go

