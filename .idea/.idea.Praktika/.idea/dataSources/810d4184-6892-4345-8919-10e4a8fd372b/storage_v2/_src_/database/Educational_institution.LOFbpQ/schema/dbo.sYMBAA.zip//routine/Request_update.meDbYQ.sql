
-- ПРОЦЕДУРА ИЗМЕНЕНИЯ ДЛЯ ТАБЛИЦЫ "Запрос"
create procedure [dbo].[Request_update]
@ID_Request [int], @Status [bit], @Text_Request [varchar] (500), @NLP_Request_ID [int]
as
	update [dbo].[Request] set
	[Status] = @Status,
	[Text_Request] = @Text_Request,
	[NLP_Request_ID] = @NLP_Request_ID
	where [ID_Request] = @ID_Request
go

