
-- ПРОЦЕДУРА УДАЛЕНИЯ ДЛЯ ТАБЛИЦЫ "Распределение ЦМК"
create procedure [dbo].[Distribution_CMK_delete]
@ID_Distribution [int]
as
	delete [dbo].[Distribution_CMK] 
			where [ID_Distribution] = @ID_Distribution
go

