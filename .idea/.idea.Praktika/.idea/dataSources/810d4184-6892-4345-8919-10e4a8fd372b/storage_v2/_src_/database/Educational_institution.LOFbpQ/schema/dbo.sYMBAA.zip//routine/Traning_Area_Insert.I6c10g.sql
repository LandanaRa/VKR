
Create procedure [dbo].[Traning_Area_Insert]
@Full_Name [varchar] (85), @Abbreviated_Name [varchar] (42)
as
	insert into [dbo].[Traning_Area] 
	([Full_Name],[Abbreviated_Name])
	values 
	(@Full_Name, @Abbreviated_Name)
go

