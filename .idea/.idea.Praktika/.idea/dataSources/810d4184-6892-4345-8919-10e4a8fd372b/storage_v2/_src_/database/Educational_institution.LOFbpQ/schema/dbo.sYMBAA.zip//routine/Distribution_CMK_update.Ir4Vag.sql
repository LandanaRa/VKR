
-- ПРОЦЕДУРА ИЗМЕНЕНИЯ ДЛЯ ТАБЛИЦЫ "Распределение ЦМК"
create procedure [dbo].[Distribution_CMK_update]
@ID_Distribution [int], @Role_In_CMK_ID [int], @CMK_Distribution_ID [int], @Plurality_Distribution_ID [int]
as
	update [dbo].[Distribution_CMK] set
	[Role_In_CMK_ID] = @Role_In_CMK_ID,
	[CMK_Distribution_ID] = @CMK_Distribution_ID,
	[Plurality_Distribution_ID] = @Plurality_Distribution_ID
	where [ID_Distribution] = @ID_Distribution
go

