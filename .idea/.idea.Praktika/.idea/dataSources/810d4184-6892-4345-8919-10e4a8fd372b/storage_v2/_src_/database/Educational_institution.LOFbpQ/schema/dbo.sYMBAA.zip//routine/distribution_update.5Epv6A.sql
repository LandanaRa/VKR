
create procedure [dbo].[distribution_update]
@id_distribution [int],@priority [int] ,@territory_аudiences_id [int],
@nlp_id [int]
as
	update [dbo].[distribution] set
	 [priority] = @priority,
	 [territory_аudiences_id] = @territory_аudiences_id,
	 [nlp_id] = @nlp_id
	where 
	[id_distribution] = @id_distribution
go

