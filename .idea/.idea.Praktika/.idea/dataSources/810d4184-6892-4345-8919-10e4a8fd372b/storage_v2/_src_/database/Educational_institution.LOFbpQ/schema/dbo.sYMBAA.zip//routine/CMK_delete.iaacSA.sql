
-- ПРОЦЕДУРА УДАЛЕНИЯ ДЛЯ ТАБЛИЦЫ "ЦМК" (Прогнано)
create procedure [dbo].[CMK_delete]
@ID_CMK [int]
as
	delete [dbo].[CMK] 
			where [ID_CMK] = @ID_CMK
go

