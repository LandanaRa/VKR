  create view [dbo].[Distribution_Group]
("ID","Номер группы","Даты формирования","Номер кабинета")
as
SELECT
  NLP.ID_NLP
  ,[Group].Name_Group
 ,NLP.Date_Forming
 ,Territory_Аudiences.Number_Cabinet
FROM dbo.NLP
INNER JOIN dbo.[Group]
  ON NLP.Group_ID = [Group].ID_Group
INNER JOIN dbo.Distribution
  ON Distribution.NLP_ID = NLP.ID_NLP
INNER JOIN dbo.Territory_Аudiences
  ON Distribution.Territory_Аudiences_ID = Territory_Аudiences.ID_Territory_Аudiences
  go

