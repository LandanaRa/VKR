
create procedure [dbo].[EU_CMK_RUP_delete]
	@ID_EU_CMK_RUP [int]
as
delete from [dbo].[EU_CMK_RUP]
where
	[ID_EU_CMK_RUP] = @ID_EU_CMK_RUP
go

