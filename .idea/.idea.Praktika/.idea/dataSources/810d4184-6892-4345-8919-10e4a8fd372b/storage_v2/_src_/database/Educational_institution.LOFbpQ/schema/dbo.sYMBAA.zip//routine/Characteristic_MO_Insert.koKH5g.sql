Create procedure [dbo].[Characteristic_MO_Insert]
	@Indicator [varchar] (15),
	@Form_ID [int],
	@Characteristic_ID [int],
	@Material_Provisions_ID [int],
	@Inventory_Number [varchar] (15)
as
	Insert into [dbo].[Characteristic_MO]
	([Indicator],
	 [Form_ID],
	 [Characteristic_ID],
	 [Material_Provisions_ID],
	 [Inventory_Number])
values
	 (@Indicator,
	  @Form_ID,
	  @Characteristic_ID,
	  @Material_Provisions_ID,
	  @Inventory_Number)
go

