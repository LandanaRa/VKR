
-- ПРОЦЕДУРА УДАЛЕНИЯ ДЛЯ ТАБЛИЦЫ "Запрос"
create procedure [dbo].[Request_delete]
@ID_Request [int]
as
	delete [dbo].[Request] 
			where [ID_Request] = @ID_Request
go

