
CREATE procedure dbo.Schedule_NLP_update
@ID_Schedule_NLP [int],@Order_Week [bit] ,@Day_Week VARCHAR(12),@number_Classes INT, @NLPp_ID INT
as
	update [dbo].[Schedule_NLP] set
	 [Order_Week] = @Order_Week,
	 [Day_Week] = @Day_Week,
   [number_Classes] = @number_Classes,
	 [nlpp_id] = @nlpp_id
	where 
	[ID_Schedule_NLP] = @ID_Schedule_NLP
go

