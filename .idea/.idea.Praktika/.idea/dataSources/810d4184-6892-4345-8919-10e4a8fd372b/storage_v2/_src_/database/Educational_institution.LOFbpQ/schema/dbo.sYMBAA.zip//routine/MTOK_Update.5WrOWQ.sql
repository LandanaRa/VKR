
Create procedure [dbo].[MTOK_Update]
	@ID_MTOK [int],
	@Position_X [varchar] (4),
	@Position_Y [varchar] (4),
	@Width [varchar] (3),
	@Height [varchar] (3) ,
	@Territory_Аudiences_ID [int] ,
	@MTOK_ID [int],
	@Inventory_Number [varchar] (12)
as
	update [dbo].[MTOK] set
	[Position_X] = @Position_X ,
	[Position_Y] = @Position_Y ,
	[Width] = @Width ,
	[Height] = @Height  ,
	[Territory_Аudiences_ID] = @Territory_Аudiences_ID ,
	[MTOK_ID] = @MTOK_ID,
	[Inventory_Number] = @Inventory_Number 
where
	[ID_MTOK] = @ID_MTOK
go

