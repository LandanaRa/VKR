

create procedure [dbo].[Educational_Unit_insert]
	@Name_Of_The_EU[varchar] (30)
as
insert into [dbo].[Educational_Unit] ([Name_Of_The_EU])
values (@Name_Of_The_EU)
go

