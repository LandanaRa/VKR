

create procedure [dbo].[criteria_insert]
	@Name_criteria [varchar] (100), @kind_criteria_ID [int], @ranging [int]
as
	insert into [dbo].[criteria] ([Name_criteria],[kind_criteria_ID],[ranging])
	values (@Name_criteria,@kind_criteria_ID,@ranging)
go

