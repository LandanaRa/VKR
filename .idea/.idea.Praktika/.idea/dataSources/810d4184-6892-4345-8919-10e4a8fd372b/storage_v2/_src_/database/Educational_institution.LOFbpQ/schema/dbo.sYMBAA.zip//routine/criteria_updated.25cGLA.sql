create procedure [dbo].[criteria_updated]
@ID_criteria [int], @Name_criteria[varchar] (30), @kind_criteria_ID [int], @ranging [int]
as
update [dbo].[criteria] set
[Name_criteria] = @Name_criteria,
[kind_criteria_ID] = @kind_criteria_ID,
[ranging] = @ranging
where
[ID_criteria] = @ID_criteria

go

