-- ПРОЦЕДУРА ДОБАВЛЕНИЯ ДЛЯ ТАБЛИЦЫ "ЦМК" (Прогнано)
create procedure [dbo].[CMK_insert] 
@Name_CMK [varchar] (50)
as
	insert into [dbo].[CMK] ([Name_CMK]) values 
	(@Name_CMK)
go

