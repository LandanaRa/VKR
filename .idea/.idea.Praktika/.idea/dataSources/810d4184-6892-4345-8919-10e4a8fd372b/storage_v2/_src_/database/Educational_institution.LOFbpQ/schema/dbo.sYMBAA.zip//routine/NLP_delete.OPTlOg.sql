
-- ПРОЦЕДУРА УДАЛЕНИЯ ДЛЯ ТАБЛИЦЫ "НЛП"
create procedure [dbo].[NLP_delete]
@ID_NLP [int]
as
	delete [dbo].[NLP] 
			where [ID_NLP] = @ID_NLP
go

