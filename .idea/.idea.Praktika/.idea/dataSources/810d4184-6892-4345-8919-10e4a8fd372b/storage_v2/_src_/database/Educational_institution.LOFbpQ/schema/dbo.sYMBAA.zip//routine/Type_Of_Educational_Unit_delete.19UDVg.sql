

create procedure [dbo].[Type_Of_Educational_Unit_delete]
	@ID_Type_Of_Educational_Unit [int]
as
delete from [dbo].[Type_Of_Educational_Unit]
where
	[ID_Type_Of_Educational_Unit] = @ID_Type_Of_Educational_Unit
go

