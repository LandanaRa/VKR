
create procedure [dbo].[Schedule_NLP_delete]
@ID_Schedule_NLP [int]
as
	delete from [dbo].[Schedule_NLP]
	where
		[ID_Schedule_NLP] = @ID_Schedule_NLP
go

