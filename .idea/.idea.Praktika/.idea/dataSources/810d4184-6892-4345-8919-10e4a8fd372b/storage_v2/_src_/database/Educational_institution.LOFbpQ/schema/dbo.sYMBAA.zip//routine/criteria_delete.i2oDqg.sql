
create procedure [dbo].[criteria_delete]
	@ID_criteria [int]
as
	delete from [dbo].[criteria]
where
	[ID_criteria] = @ID_criteria
go

