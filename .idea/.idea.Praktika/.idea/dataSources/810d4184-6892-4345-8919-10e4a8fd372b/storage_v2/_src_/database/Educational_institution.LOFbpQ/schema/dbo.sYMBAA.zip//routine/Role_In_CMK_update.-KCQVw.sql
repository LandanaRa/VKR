
-- ПРОЦЕДУРА ИЗМЕНЕНИЯ ДЛЯ ТАБЛИЦЫ "Роль в ЦМК" (Прогнано)
create procedure [dbo].[Role_In_CMK_update]
@ID_Role_In_CMK [int], @Name_Role [varchar] (30)
as
	update [dbo].[Role_In_CMK] set
	[Name_Role] = @Name_Role
	where [ID_Role_In_CMK] = @ID_Role_In_CMK
go

