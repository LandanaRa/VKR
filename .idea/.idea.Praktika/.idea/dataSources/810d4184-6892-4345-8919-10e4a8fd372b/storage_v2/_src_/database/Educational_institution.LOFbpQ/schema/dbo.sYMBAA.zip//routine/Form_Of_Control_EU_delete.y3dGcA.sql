
create procedure [dbo].[Form_Of_Control_EU_delete]
	@ID_Form_Of_Control_EU [int]
as
delete from [dbo].[Form_Of_Control_EU]
where
	[ID_Form_Of_Control_EU] = @ID_Form_Of_Control_EU
go

