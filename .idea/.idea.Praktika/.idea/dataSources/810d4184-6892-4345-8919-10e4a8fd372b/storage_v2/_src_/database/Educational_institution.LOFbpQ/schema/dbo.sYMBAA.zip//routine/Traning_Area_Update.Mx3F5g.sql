
Create procedure [dbo].[Traning_Area_Update]
@ID_Traning_Area [int], @Full_Name [varchar] (85), @Abbreviated_Name [varchar] (42)
as
	update [dbo].[Traning_Area] set
	[Full_Name] = @Full_Name,
	[Abbreviated_Name] = @Abbreviated_Name
where
	[ID_Training_Area] = @ID_Traning_Area
go

