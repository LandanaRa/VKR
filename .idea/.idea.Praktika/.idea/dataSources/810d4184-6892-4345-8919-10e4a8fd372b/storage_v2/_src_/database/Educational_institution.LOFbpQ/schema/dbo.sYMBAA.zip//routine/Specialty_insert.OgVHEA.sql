-- ПРОЦЕДУРА ДОБАВЛЕНИЯ "Специальность" (Прогнано)
create procedure [dbo].[Specialty_insert] 
@Number_Specialty [varchar] (10), @Name_Specialty [varchar] (50)
as
	insert into [dbo].[Specialty] ([Number_Specialty], [Name_Specialty]) 
	values 
	(@Number_Specialty, @Name_Specialty)
go

