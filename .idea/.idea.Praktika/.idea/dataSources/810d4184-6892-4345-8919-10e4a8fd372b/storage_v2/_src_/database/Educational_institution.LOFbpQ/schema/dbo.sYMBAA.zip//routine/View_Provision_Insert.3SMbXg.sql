Create procedure [dbo].[View_Provision_Insert]
@Name_View_Provision [varchar] (45)
as insert into [dbo].[View_Provision]
([Name_View_Provision])
values
(@Name_View_Provision)
go

