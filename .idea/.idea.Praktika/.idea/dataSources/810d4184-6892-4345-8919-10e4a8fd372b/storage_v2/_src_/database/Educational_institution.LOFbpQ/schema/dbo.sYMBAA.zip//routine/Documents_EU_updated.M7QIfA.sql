
create procedure [dbo].[Documents_EU_updated]
	@ID_Documents_EU [int], @Document_Title[varchar] (30), @Link_To_The_Document [varchar] (max), @Document_Template_ID [int], @EU_CMK_RUP_ID [int]
as
update [dbo].[Documents_EU] set
	[Document_Title] = @Document_Title,
	[Link_To_The_Document] = @Link_To_The_Document,
	[Document_Template_ID] = @Document_Template_ID,
	[EU_CMK_RUP_ID] = @EU_CMK_RUP_ID
where
	[ID_Documents_EU] = @ID_Documents_EU

go

