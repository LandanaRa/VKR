
-- ПРОЦЕДУРА ИЗМЕНЕНИЯ "Специальность" (Прогнано)
create procedure [dbo].[Specialty_update]
@ID_Specialty [int], @Number_Specialty [varchar] (10), @Name_Specialty [varchar] (50)
as
	update [dbo].[Specialty] set
	[Number_Specialty] = @Number_Specialty,
	[Name_Specialty] = @Name_Specialty
	where [ID_Specialty] = @ID_Specialty
go

