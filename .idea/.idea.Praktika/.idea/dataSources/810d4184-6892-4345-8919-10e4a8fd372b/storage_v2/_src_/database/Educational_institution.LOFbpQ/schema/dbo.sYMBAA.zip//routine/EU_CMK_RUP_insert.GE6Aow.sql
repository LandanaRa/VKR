create procedure [dbo].[EU_CMK_RUP_insert]
@Prefix[varchar] (30), @Total_Number_Of_Hours[varchar] (3), @Theoretical_Hours [varchar] (3), @Lab_Prac_Hours [varchar] (3), 
@Individual_Work [varchar] (5),@Consultations [varchar] (5), @Coursework_Project [varchar] (5), @Interim_Certification [varchar] (5), 
@Educational_Unit_ID [int], @Type_Of_Educational_Unit_ID [int],
@Form_Of_Control_EU_ID [int], @CMK_RUP_ID [int], @EU_CMK_RUP_ID [int]
as
insert into [dbo].[EU_CMK_RUP] ([Prefix], [Total_Number_Of_Hours], [Theoretical_Hours], [Lab_Prac_Hours], [Individual_Work], [Consultations],
[Coursework_Project], [Interim_Certification], [Educational_Unit_ID], [Type_Of_Educational_Unit_ID], [Form_Of_Control_EU_ID], [CMK_RUP_ID], [EU_CMK_RUP_ID])
values (@Prefix, @Total_Number_Of_Hours, @Theoretical_Hours, @Lab_Prac_Hours, @Individual_Work,
@Consultations, @Coursework_Project, @Interim_Certification, @Educational_Unit_ID, @Type_Of_Educational_Unit_ID,
@Form_Of_Control_EU_ID, @CMK_RUP_ID, @EU_CMK_RUP_ID)
go

