
Create procedure [dbo].[Material_Provision_Delete]
@ID_Material_Provision [int]
as
delete from [dbo].[Material_Provision]
where [ID_Material_Provision] = @ID_Material_Provision
go

