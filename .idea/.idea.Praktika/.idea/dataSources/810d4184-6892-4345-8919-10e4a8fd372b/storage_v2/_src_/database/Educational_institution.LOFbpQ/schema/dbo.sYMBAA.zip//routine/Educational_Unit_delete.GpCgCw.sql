
create procedure [dbo].[Educational_Unit_delete]
	@ID_Educational_Unit [int]
as
delete from [dbo].[Educational_Unit]
where
	[ID_Educational_Unit] = @ID_Educational_Unit
go

