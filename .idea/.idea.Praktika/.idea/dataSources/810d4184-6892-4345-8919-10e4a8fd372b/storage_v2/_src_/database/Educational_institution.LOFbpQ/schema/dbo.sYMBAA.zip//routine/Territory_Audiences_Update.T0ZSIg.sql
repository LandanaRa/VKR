
Create procedure [dbo].[Territory_Аudiences_Update]
	@ID_Territory_Аudiences [int],
	 @Number_Cabinet [varchar] (4),
	@Position_X [varchar] (4),
	@Position_Y [varchar] (4),
	@Width [varchar] (3),
	@Height [varchar] (3) ,
	@Color_ID [int] ,
	@Traning_Area_ID [int],
	@View_ID [int]
as
	update [dbo].[Territory_Аudiences] set
	[Number_Cabinet] =  @Number_Cabinet,
	[Position_X] = @Position_X ,
	[Position_Y] = @Position_Y ,
	[Width] = @Width ,
	[Height] = @Height  ,
	[Color_ID] = @Color_ID ,
	[Traning_Area_ID] = @Traning_Area_ID,
	[View_ID] = @View_ID 
where
	[ID_Territory_Аudiences] = @ID_Territory_Аudiences
go

