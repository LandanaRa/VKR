Create procedure [dbo].[Material_Provision_Insert]
@Name_Material_Provision [varchar] (45)
as insert into [dbo].[Material_Provision]
([Name_Material_Provision])
values
(@Name_Material_Provision)
go

