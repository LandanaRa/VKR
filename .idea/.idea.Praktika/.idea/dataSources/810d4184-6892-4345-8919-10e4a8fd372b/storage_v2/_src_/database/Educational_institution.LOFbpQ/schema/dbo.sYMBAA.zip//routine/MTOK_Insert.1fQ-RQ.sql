Create procedure [dbo].[MTOK_Insert]
	@Position_X [varchar] (4),
	@Position_Y [varchar] (4),
	@Width [varchar] (3),
	@Height [varchar] (3) ,
    @Inventory_Number [varchar] (12),
	@Territory_Аudiences_ID [int] ,
	@MTOK_ID [int]
as insert into [dbo].[MTOK] 
	       ([Position_X],
		    [Position_Y],
			[Width],
			[Height],
			[Territory_Аudiences_ID],
			[MTOK_ID])
	values (@Position_X,
	        @Position_Y,
			@Width,
			@Height,
			@Territory_Аudiences_ID,
			@MTOK_ID)
go

