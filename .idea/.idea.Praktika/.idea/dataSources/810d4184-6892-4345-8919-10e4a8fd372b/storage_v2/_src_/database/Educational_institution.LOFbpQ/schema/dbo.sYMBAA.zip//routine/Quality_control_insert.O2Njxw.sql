 
create procedure [dbo].[Quality_control_insert]
	@Date_Of_Hosting [varchar] (10), @criteria_ID [int], @MTOK_ID [int]
as
	insert into [dbo].[Quality_control] ([Date_Of_Hosting],[criteria_ID],[MTOK_ID])
	values (@Date_Of_Hosting,@criteria_ID,@MTOK_ID)
go

