
Create procedure [dbo].[Characteristic_MO_Delete]
@ID_Characteristic_MO [int]
as
	Delete from [dbo].[Characteristic_MO]
where
	[ID_Characteristic_MO] = @ID_Characteristic_MO
go

