create view [dbo].[Groups_Employes]
("ID","Имя","Фамилия","Дата формирование","Номер кабинета","Территория")
as
SELECT
  Plurality.Id_Plurality
 ,Employees.Name
 ,Employees.Surname
 ,NLP.Date_Forming
 ,Territory_Аudiences.Number_Cabinet
 ,View_Cabinet.Name_View_Cabinet
FROM dbo.Plurality
INNER JOIN dbo.Employees
  ON Plurality.EmployeeId_Employee = Employees.Id_Employee
INNER JOIN dbo.Distribution_CMK
  ON Distribution_CMK.Plurality_Distribution_ID = Plurality.Id_Plurality
INNER JOIN dbo.NLP
  ON NLP.Distribution_ID = Distribution_CMK.ID_Distribution
INNER JOIN dbo.Distribution
  ON Distribution.NLP_ID = NLP.ID_NLP
INNER JOIN dbo.Territory_Аudiences
  ON Distribution.Territory_Аudiences_ID = Territory_Аudiences.ID_Territory_Аudiences
INNER JOIN dbo.View_Cabinet
  ON Territory_Аudiences.View_ID = View_Cabinet.ID_View

go

