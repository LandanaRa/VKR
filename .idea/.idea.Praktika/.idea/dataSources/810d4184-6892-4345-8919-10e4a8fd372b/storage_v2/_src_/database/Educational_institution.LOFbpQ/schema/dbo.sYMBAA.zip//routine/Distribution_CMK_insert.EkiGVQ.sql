create procedure [dbo].[Distribution_CMK_insert] 
@Role_In_CMK_ID [int], @CMK_Distribution_ID [int], @Plurality_Distribution_ID [int]
as
	insert into [dbo].[Distribution_CMK] ([Role_In_CMK_ID], [CMK_Distribution_ID], [Plurality_Distribution_ID]) values 
	(@Role_In_CMK_ID, @CMK_Distribution_ID, @Plurality_Distribution_ID)
go

