
Create procedure [dbo].[View_Provision_Update]
@ID_View_Provision [int], @Name_View_Provision [varchar] (45)
as 
	update [dbo].[View_Provision] set
	[Name_View_Provision] = @Name_View_Provision
where
	[ID_View_Provision] = @ID_View_Provision
go

