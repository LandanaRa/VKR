
-- ПРОЦЕДУРА УДАЛЕНИЯ ДЛЯ ТАБЛИЦЫ "ЦМК РУП"
create procedure [dbo].[CMK_RUP_delete]
@ID_CMK_RUP [int]
as
	delete [dbo].[CMK_RUP] 
			where [ID_CMK_RUP] = @ID_CMK_RUP
go

