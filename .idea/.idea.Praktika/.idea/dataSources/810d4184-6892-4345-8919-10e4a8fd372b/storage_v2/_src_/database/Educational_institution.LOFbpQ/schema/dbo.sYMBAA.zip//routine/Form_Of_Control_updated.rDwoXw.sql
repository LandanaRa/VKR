
create procedure [dbo].[Form_Of_Control_updated]
	@ID_Form_Of_Control [int], @Name_Of_The_Form[varchar] (30)
as
update [dbo].[Form_Of_Control] set
	[Name_Of_The_Form] = @Name_Of_The_Form
where
	[ID_Form_Of_Control] = @ID_Form_Of_Control

go

