create procedure [dbo].[Document_Template_insert]
	@Document_Title[varchar] (30), @Path_To_File [varchar] (max)
as
insert into [dbo].[Document_Template] ([Document_Title],[Path_To_File])
values (@Document_Title,@Path_To_File)
go

