
Create procedure [dbo].[Characteristic_Update]
@ID_Characteristic [int], @Name_Characteristic [varchar] (55), @View_Provision_ID [int]
as
	update [dbo].[Characteristic] set
    [Name_Characteristic] = @Name_Characteristic,
	[View_Provisions_ID] = @View_Provision_ID
where
	[ID_Characteristic] = @ID_Characteristic
go

