
create procedure [dbo].[Document_Template_delete]
	@ID_Document_Template [int]
as
delete from [dbo].[Document_Template]
where
	[ID_Document_Template] = @ID_Document_Template
go

