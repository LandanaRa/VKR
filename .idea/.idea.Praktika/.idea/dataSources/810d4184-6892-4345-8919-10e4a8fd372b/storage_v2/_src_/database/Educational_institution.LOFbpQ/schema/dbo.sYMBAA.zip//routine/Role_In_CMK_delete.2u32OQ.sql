
-- ПРОЦЕДУРА УДАЛЕНИЯ ДЛЯ ТАБЛИЦЫ "Роль в ЦМК" (Прогнано)
create procedure [dbo].[Role_In_CMK_delete]
@ID_Role_In_CMK [int]
as
	delete [dbo].[Role_In_CMK] 
			where [ID_Role_In_CMK] = @ID_Role_In_CMK
go

