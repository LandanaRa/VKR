
-- ПРОЦЕДУРА ИЗМЕНЕНИЯ "Группа" (Прогнано)
create procedure [dbo].[Group_update]
@ID_Group [int], @Name_Group [varchar] (15), @Specialty_ID [int]
as
	update [dbo].[Group] set
	[Name_Group] = @Name_Group,
	[Specialty_ID] = @Specialty_ID
	where [ID_Group] = @ID_Group
go

