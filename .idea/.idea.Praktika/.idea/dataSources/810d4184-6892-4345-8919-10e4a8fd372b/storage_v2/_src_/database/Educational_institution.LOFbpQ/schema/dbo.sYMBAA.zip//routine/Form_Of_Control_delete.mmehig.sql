
create procedure [dbo].[Form_Of_Control_delete]
	@ID_Form_Of_Control [int]
as
delete from [dbo].[Form_Of_Control]
where
	[ID_Form_Of_Control] = @ID_Form_Of_Control
go

