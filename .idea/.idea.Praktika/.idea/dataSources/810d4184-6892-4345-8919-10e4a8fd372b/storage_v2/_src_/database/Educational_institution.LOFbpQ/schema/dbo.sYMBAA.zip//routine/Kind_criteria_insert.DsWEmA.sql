create procedure [dbo].[Kind_criteria_insert]
	@Name_of_kind_criteria [varchar] (100)
as
	insert into [dbo].[Kind_criteria] (Name_of_kind_criteria)
	values (@Name_of_kind_criteria)
go

