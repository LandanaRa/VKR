

create procedure [dbo].[Form_Of_Control_EU_insert]
	@Number_Of_Semester[varchar] (30), @Form_Of_Control_ID [int]
as
insert into [dbo].[Form_Of_Control_EU] ([Number_Of_Semester], [Form_Of_Control_ID])
values (@Number_Of_Semester, @Form_Of_Control_ID)
go

