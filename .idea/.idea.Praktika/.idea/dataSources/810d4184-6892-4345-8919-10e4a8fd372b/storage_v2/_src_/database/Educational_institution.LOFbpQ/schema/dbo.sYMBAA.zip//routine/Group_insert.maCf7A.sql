-- ПРОЦЕДУРА ДОБАВЛЕНИЯ "Группа" (Прогнано)
create procedure [dbo].[Group_insert] 
@Name_Group [varchar] (15), @Specialty_ID [int]
as
	insert into [dbo].[Group] ([Name_Group], [Specialty_ID]) 
	values 
	(@Name_Group, @Specialty_ID)
go

