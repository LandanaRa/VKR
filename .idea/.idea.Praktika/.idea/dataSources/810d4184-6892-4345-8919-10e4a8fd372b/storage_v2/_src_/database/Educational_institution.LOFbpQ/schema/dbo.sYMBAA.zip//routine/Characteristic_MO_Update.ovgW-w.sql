
Create procedure [dbo].[Characteristic_MO_Update]
	@ID_Characteristic_MO [int],
	@Indicator [varchar] (15),
	@Form_ID [int],
	@Characteristic_ID [int],
	@Material_Provisions_ID [int],
	@Inventory_Number [varchar] (15)
as
	Update [dbo].[Characteristic_MO] set
	[Indicator] = @Indicator,
	[Form_ID] = @Form_ID,
	[Characteristic_ID] = @Characteristic_ID,
	[Material_Provisions_ID] = @Material_Provisions_ID,
	[Inventory_Number] = @Inventory_Number
where
	[ID_Characteristic_MO] = @ID_Characteristic_MO
go

