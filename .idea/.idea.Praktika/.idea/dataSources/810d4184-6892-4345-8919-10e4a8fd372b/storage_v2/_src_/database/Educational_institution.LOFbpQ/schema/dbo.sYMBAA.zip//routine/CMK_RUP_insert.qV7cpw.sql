create procedure [dbo].[CMK_RUP_insert] 
@RUP_ID [int], @CMK_ID [int]
as
	insert into [dbo].[CMK_RUP] ([RUP_ID], [CMK_ID]) values 
	(@RUP_ID, @CMK_ID)
go

