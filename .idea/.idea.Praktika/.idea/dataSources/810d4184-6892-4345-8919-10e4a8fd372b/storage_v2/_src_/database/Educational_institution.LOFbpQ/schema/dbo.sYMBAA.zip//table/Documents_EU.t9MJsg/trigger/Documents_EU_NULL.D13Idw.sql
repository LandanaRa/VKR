create trigger Documents_EU_NULL
ON dbo.Documents_EU

AFTER INSERT, UPDATE, DELETE
AS
begin
	select * from dbo.Documents_EU where Link_To_The_Document is null;
end
go

