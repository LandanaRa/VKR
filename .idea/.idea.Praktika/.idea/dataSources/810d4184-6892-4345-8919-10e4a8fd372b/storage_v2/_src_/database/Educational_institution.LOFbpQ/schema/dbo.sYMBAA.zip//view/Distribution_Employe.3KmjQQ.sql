create view [dbo].[Distribution_Employe]
("ID","Фамилия сотрудника","Имя сотрудника","Номер сотрудника","Распределение ЦМК","Дата формирования","Приоритет","Номер кабинета")
as
SELECT
  Distribution.ID_Distribution
  ,Employees.Surname
 ,Employees.Name
 ,Plurality.EmployeeId_Employee
 ,Distribution_CMK.Plurality_Distribution_ID
 ,NLP.Date_Forming
 ,Distribution.Priority
 ,Territory_Аudiences.Number_Cabinet
FROM dbo.Distribution
INNER JOIN dbo.NLP
  ON Distribution.NLP_ID = NLP.ID_NLP
INNER JOIN dbo.Distribution_CMK
  ON NLP.Distribution_ID = Distribution_CMK.ID_Distribution
INNER JOIN dbo.Plurality
  ON Distribution_CMK.Plurality_Distribution_ID = Plurality.Id_Plurality
INNER JOIN dbo.Employees
  ON Plurality.EmployeeId_Employee = Employees.Id_Employee
INNER JOIN dbo.Territory_Аudiences
  ON Distribution.Territory_Аudiences_ID = Territory_Аudiences.ID_Territory_Аudiences

go

