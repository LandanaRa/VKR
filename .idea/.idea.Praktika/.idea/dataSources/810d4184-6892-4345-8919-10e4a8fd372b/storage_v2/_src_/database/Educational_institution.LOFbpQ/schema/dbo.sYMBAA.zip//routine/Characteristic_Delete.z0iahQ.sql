
Create procedure [dbo].[Characteristic_Delete]
@ID_Characteristic [int]
as
	delete from [dbo].[Characteristic]
where
	[ID_Characteristic] = @ID_Characteristic
go

