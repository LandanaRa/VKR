
-- ПРОЦЕДУРА УДАЛЕНИЯ "Группа" (Прогнано)
create procedure [dbo].[Group_delete]
@ID_Group [int]
as
	delete [dbo].[Group] 
			where [ID_Group] = @ID_Group
go

