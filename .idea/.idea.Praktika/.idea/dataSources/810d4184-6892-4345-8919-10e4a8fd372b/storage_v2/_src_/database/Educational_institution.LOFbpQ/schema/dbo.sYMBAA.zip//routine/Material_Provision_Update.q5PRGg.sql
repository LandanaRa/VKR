
Create procedure [dbo].[Material_Provision_Update]
@ID_View_Provision [int], @Name_View_Provision [varchar] (45)
as 
	update [dbo].[Material_Provision] set
	[Name_Material_Provision] = @Name_View_Provision
where
	[ID_Material_Provision] = @ID_View_Provision
go

