
-- ПРОЦЕДУРА УДАЛЕНИЯ "Специальность" (Прогнано)
create procedure [dbo].[Specialty_delete]
@ID_Specialty [int]
as
	delete [dbo].[Specialty] 
			where [ID_Specialty] = @ID_Specialty
go

