
Create procedure [dbo].[View_Provision_Delete]
@ID_View_Provision [int]
as
delete from [dbo].[View_Provision]
where [ID_View_Provision] = @ID_View_Provision
go

