
create procedure [dbo].[Educational_Unit_updated]
	@ID_Educational_Unit [int], @Name_Of_The_EU[varchar] (30)
as
update [dbo].[Educational_Unit] set
	[Name_Of_The_EU] = @Name_Of_The_EU
where
	[ID_Educational_Unit] = @ID_Educational_Unit

go

