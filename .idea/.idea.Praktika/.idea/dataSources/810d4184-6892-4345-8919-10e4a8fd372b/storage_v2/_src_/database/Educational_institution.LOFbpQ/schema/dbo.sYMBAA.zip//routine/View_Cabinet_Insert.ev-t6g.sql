

Create procedure [dbo].[View_Cabinet_Insert]
@Name_View_Cabinet [varchar] (35)
as
	insert into [dbo].[View_Cabinet] ([Name_View_Cabinet])
	values (@Name_View_Cabinet)
go

