
create procedure [dbo].[Quality_control_updated]
	@ID_quality_control [int], @Date_Of_Hosting[varchar] (30), @criteria_ID [int], @MTOK_ID [int]
as
	update [dbo].[Quality_control] set
	[Date_Of_Hosting] = @Date_Of_Hosting,
	[criteria_ID] = @criteria_ID,
	[MTOK_ID] = @MTOK_ID
where
	[ID_quality_control] = @ID_quality_control

go

