

create procedure [dbo].[Documents_EU_insert]
	@Document_Title[varchar] (30), @Link_To_The_Document [varchar] (max), @Document_Template_ID [int], @EU_CMK_RUP_ID [int]
as
insert into [dbo].[Documents_EU] ([Document_Title],[Link_To_The_Document],[Document_Template_ID], [EU_CMK_RUP_ID])
values (@Document_Title,@Link_To_The_Document, @Document_Template_ID,@EU_CMK_RUP_ID)
go

