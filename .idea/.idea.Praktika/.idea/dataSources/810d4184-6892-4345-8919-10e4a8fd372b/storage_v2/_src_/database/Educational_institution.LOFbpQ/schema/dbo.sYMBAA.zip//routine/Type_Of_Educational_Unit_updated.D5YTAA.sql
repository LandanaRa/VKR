
create procedure [dbo].[Type_Of_Educational_Unit_updated]
	@ID_Type_Of_Educational_Unit [int], @Number_Of_Type[varchar] (30)
as
update [dbo].[Type_Of_Educational_Unit] set
	[Number_Of_Type] = @Number_Of_Type
where
	[ID_Type_Of_Educational_Unit] = @ID_Type_Of_Educational_Unit

go

