
create procedure [dbo].[distribution_delete]
@id_distribution [int]
as
	delete from [dbo].[distribution]
	where
		[id_distribution] = @id_distribution
go

