

create procedure [dbo].[Type_Of_Educational_Unit_insert]
	@Number_Of_Type[varchar] (30)
as
insert into [dbo].[Type_Of_Educational_Unit] ([Number_Of_Type])
values (@Number_Of_Type)
go

