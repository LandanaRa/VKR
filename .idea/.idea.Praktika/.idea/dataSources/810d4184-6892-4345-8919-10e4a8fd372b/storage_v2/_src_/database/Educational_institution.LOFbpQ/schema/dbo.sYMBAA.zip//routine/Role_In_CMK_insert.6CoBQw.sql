-- ПРОЦЕДУРА ДОБАВЛЕНИЯ ДЛЯ ТАБЛИЦЫ "Роль в ЦМК" (Прогнано)
create procedure [dbo].[Role_In_CMK_insert] 
@Name_Role [varchar] (50)
as
	insert into [dbo].[Role_In_CMK] ([Name_Role]) values 
	(@Name_Role)
go

