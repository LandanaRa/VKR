
-- ПРОЦЕДУРА ИЗМЕНЕНИЯ ДЛЯ ТАБЛИЦЫ "ЦМК" (Прогнано)
create procedure [dbo].[CMK_update]
@ID_CMK [int], @Name_CMK [varchar] (30)
as
	update [dbo].[CMK] set
	[Name_CMK] = @Name_CMK
	where [ID_CMK] = @ID_CMK
go

