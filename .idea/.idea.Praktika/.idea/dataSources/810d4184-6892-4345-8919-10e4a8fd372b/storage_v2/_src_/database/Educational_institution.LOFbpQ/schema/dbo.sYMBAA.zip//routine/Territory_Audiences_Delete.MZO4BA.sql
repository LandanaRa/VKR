
Create procedure [dbo].[Territory_Аudiences_Delete]
@ID_Territory_Аudiences [int]
as
	delete from [dbo].[Territory_Аudiences]
	where
	[ID_Territory_Аudiences] = @ID_Territory_Аudiences
go

