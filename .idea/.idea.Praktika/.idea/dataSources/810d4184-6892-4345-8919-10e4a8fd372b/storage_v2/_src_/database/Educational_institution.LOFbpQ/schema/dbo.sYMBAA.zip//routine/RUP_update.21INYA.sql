
-- ПРОЦЕДУРА ИЗМЕНЕНИЯ "РУП" (Прогнано)
create procedure [dbo].[RUP_update]
@ID_RUP [int], @Year_Of_Flow [varchar] (4), @Period_Of_Study [varchar] (10), @Specialty_RUP_ID [int]
as
	update [dbo].[RUP] set
	[Year_Of_Flow] = @Year_Of_Flow,
	[Period_Of_Study] = @Period_Of_Study,
	[Specialty_RUP_ID] = @Specialty_RUP_ID
	where [ID_RUP] = @ID_RUP
go

