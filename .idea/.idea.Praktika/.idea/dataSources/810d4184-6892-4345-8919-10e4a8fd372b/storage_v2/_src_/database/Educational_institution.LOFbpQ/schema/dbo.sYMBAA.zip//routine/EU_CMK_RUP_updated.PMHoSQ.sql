
create procedure [dbo].[EU_CMK_RUP_updated]
	@ID_EU_CMK_RUP [int], @Prefix[varchar] (9), @Total_Number_Of_Hours [varchar] (3), @Theoretical_Hours [varchar] (3), @Lab_Prac_Hours [varchar] (3), @Individual_Work [varchar] (5),
	@Consultations [varchar] (5), @Coursework_Project [varchar] (5), @Interim_Certification [varchar] (5), @Educational_Unit_ID [int], @Type_Of_Educational_Unit_ID [int],
	@Form_Of_Control_EU_ID [int], @CMK_RUP_ID [int], @EU_CMK_RUP_ID [int]
as
update [dbo].[EU_CMK_RUP] set
	[Prefix] = @Prefix,
	[Total_Number_Of_Hours] = @Total_Number_Of_Hours,
	[Theoretical_Hours] = @Theoretical_Hours,
	[Lab_Prac_Hours] = @Lab_Prac_Hours,
	[Individual_Work] = @Individual_Work,
	[Consultations] = @Consultations,
	[Coursework_Project] = @Coursework_Project,
	[Interim_Certification] = @Interim_Certification,
	[Educational_Unit_ID] = @Educational_Unit_ID,
	[Type_Of_Educational_Unit_ID] = @Type_Of_Educational_Unit_ID,
	[Form_Of_Control_EU_ID] = @Form_Of_Control_EU_ID,
	[CMK_RUP_ID] = @CMK_RUP_ID,
	[EU_CMK_RUP_ID] = @EU_CMK_RUP_ID
where
	[ID_EU_CMK_RUP] = @ID_EU_CMK_RUP

go

