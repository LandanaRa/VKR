CREATE procedure dbo.Schedule_NLP_insert
@Order_Week [bit] ,@Day_Week VARCHAR(12),@number_Classes INT, @NLPp_ID INT
as
	insert into [dbo].[Schedule_NLP] ([Order_Week],[Day_Week],[Number_Classes],[NLPp_ID])
	values (@Order_Week,@Day_Week,@number_Classes,@NLPp_ID)
go

