-- ПРОЦЕДУРА ДОБАВЛЕНИЯ "РУП" (Прогнано)
create procedure [dbo].[RUP_insert] 
@Year_Of_Flow [varchar] (4), @Period_Of_Study [varchar] (10), @Specialty_RUP_ID [int]
as
	insert into [dbo].[RUP] ([Year_Of_Flow], [Period_Of_Study], [Specialty_RUP_ID]) 
	values 
	(@Year_Of_Flow, @Period_Of_Study, @Specialty_RUP_ID)
go

