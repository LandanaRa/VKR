
create procedure [dbo].[Documents_EU_delete]
	@ID_Documents_EU [int]
as
delete from [dbo].[Documents_EU]
where
	[ID_Documents_EU] = @ID_Documents_EU
go

