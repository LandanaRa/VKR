create procedure [dbo].[distribution_insert]
@priority [int] ,@territory_аudiences_id [int],
@nlp_id [int]
as
	insert into [dbo].[distribution] ([priority],[territory_аudiences_id],[nlp_id])
	values (@priority,@territory_аudiences_id,@nlp_id)
go

