Create procedure [dbo].[Characteristic_Insert]
@Name_Characteristic [varchar] (55), @View_Provision_ID [int]
as
	insert into [dbo].[Characteristic]
    ([Name_Characteristic],
	 [View_Provisions_ID])
values
	 (@Name_Characteristic,
	  @View_Provision_ID)
go

