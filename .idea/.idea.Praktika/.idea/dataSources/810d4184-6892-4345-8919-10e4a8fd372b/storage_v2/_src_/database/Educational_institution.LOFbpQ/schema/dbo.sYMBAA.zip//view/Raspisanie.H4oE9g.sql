create view [dbo].[Raspisanie]
("ID","Числитель/знаминатель","День недели","Номер занятия","Номер группы","Номер специальности","Номер кабинета","Территория проведения")
as
SELECT
  Schedule_NLP.ID_Schedule_NLP
  ,Schedule_NLP.Order_Week
 ,Schedule_NLP.Day_Week
 ,Schedule_NLP.Number_Classes
 ,[Group].Name_Group
 ,Specialty.Number_Specialty
 ,Territory_Аudiences.Number_Cabinet
 ,View_Cabinet.Name_View_Cabinet
FROM dbo.Schedule_NLP
INNER JOIN dbo.NLP
  ON Schedule_NLP.NLPp_ID = NLP.ID_NLP
INNER JOIN dbo.Distribution
  ON Distribution.NLP_ID = NLP.ID_NLP
INNER JOIN dbo.[Group]
  ON NLP.Group_ID = [Group].ID_Group
INNER JOIN dbo.Specialty
  ON [Group].Specialty_ID = Specialty.ID_Specialty
INNER JOIN dbo.Territory_Аudiences
  ON Distribution.Territory_Аudiences_ID = Territory_Аudiences.ID_Territory_Аudiences
INNER JOIN dbo.View_Cabinet
  ON Territory_Аudiences.View_ID = View_Cabinet.ID_View
go

