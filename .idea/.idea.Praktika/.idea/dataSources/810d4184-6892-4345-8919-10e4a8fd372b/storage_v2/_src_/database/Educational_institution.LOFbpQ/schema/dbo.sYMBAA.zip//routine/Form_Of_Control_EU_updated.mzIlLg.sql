
create procedure [dbo].[Form_Of_Control_EU_updated]
	@ID_Form_Of_Control_EU [int], @Number_Of_Semester[varchar] (1), @Form_Of_Control_ID [int]
as
update [dbo].[Form_Of_Control_EU] set
	[Number_Of_Semester] = @Number_Of_Semester,
	[Form_Of_Control_ID] = @Form_Of_Control_ID
where
	[ID_Form_Of_Control_EU] = @ID_Form_Of_Control_EU

go

