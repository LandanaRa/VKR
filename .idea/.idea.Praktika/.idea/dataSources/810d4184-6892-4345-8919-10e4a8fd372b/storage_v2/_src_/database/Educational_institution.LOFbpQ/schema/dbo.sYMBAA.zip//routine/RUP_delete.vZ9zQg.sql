
-- ПРОЦЕДУРА УДАЛЕНИЯ "РУП" (Прогнано)
create procedure [dbo].[RUP_delete]
@ID_RUP [int]
as
	delete [dbo].[RUP] 
			where [ID_RUP] = @ID_RUP
go

