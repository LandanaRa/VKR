
-- ПРОЦЕДУРА ИЗМЕНЕНИЯ ДЛЯ ТАБЛИЦЫ "НЛП"
create procedure [dbo].[NLP_update]
@ID_NLP [int], @Date_Forming[varchar] (10), @Number_Of_Weeks [varchar] (3), @Hours_Per_Week [varchar] (3), 
@EU_CMK_RUP_NLP_ID [int], @Group_ID [int], @Distribution_ID [int]
as
	update [dbo].[NLP] set
	[Date_Forming] = @Date_Forming,
	[Number_Of_Weeks] = @Number_Of_Weeks,
	[Hours_Per_Week] = @Hours_Per_Week,
	[EU_CMK_RUP_NLP_ID] = @EU_CMK_RUP_NLP_ID,
	[Group_ID] = @Group_ID,
	[Distribution_ID] = @Distribution_ID
	where [ID_NLP] = @ID_NLP
go

