
create procedure [dbo].[Quality_control_delete]
	@ID_quality_control [int]
as
	delete from [dbo].[Quality_control]
where
	[ID_quality_control] = @ID_quality_control
go

