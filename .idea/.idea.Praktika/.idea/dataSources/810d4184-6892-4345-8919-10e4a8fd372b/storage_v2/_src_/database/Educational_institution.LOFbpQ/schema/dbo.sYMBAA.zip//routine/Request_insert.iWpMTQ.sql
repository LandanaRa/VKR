create procedure [dbo].[Request_insert] 
@Status [bit], @Text_Request [varchar] (500), @NLP_Request_ID [int]
as
	insert into [dbo].[Request] ([Status], [Text_Request], [NLP_Request_ID]) values 
	(@Status, @Text_Request, @NLP_Request_ID)
go

