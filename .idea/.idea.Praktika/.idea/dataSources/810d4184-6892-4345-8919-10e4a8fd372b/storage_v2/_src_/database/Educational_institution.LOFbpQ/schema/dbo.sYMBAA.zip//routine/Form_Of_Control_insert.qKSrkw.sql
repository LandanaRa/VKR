

create procedure [dbo].[Form_Of_Control_insert]
	@Name_Of_The_Form[varchar] (30)
as
insert into [dbo].[Form_Of_Control] ([Name_Of_The_Form])
values (@Name_Of_The_Form)
go

