Create procedure [dbo].[Territory_Аudiences_Insert]
    @Number_Cabinet [Varchar] (4),
	@Position_X [varchar] (4),
	@Position_Y [varchar] (4),
	@Width [varchar] (3),
	@Height [varchar] (3) ,
	@Color_ID [int] ,
	@Traning_Area_ID [int],
	@View_ID [int]
as insert into [dbo].[Territory_Аudiences] 
	       ([Number_Cabinet],
		    [Position_X],
		    [Position_Y],
			[Width],
			[Height],
			[Color_ID],
			[Traning_Area_ID],
			[View_ID])
	values (@Number_Cabinet,
	        @Position_X,
	        @Position_Y,
			@Width,
			@Height,
			@Color_ID,
			@Traning_Area_ID,
			@View_ID)
go

