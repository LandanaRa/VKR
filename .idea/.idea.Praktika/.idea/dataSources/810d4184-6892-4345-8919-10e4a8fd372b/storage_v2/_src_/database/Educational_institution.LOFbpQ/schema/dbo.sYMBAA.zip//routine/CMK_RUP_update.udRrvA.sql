
-- ПРОЦЕДУРА ИЗМЕНЕНИЯ ДЛЯ ТАБЛИЦЫ "ЦМК РУП"
create procedure [dbo].[CMK_RUP_update]
@ID_CMK_RUP [int], @RUP_ID [int], @CMK_ID [int]
as
	update [dbo].[CMK_RUP] set
	[RUP_ID] = @RUP_ID,
	[CMK_ID] = @CMK_ID
	where [ID_CMK_RUP] = @ID_CMK_RUP
go

