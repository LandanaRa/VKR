
create procedure [dbo].[Document_Template_updated]
	@ID_Document_Template [int], @Document_Title[varchar] (30), @Path_To_File [varchar] (max)
as
update [dbo].[Document_Template] set
	[Document_Title] = @Document_Title,
	[Path_To_File] = @Path_To_File
where
	[ID_Document_Template] = @ID_Document_Template

go

